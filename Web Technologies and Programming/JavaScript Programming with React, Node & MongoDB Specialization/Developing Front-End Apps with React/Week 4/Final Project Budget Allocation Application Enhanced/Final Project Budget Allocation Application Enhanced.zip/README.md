# React Budget App

To run:

```
npm install 
npm start 
```
